create database zomato;
use zomato;
CREATE TABLE goldusers_signup(userid integer not null primary key ,gold_signup_date date); 

INSERT INTO goldusers_signup(userid,gold_signup_date) 
 VALUES (1,'2017-09-22'),
(3,'2017-04-21');


CREATE TABLE users(userid integer ,signup_date date,foreign key(userid) references goldusers_signup(userid) ); 

INSERT INTO users(userid,signup_date) 
 VALUES (1,'2014-09-02'),
(2,'2015-01-15'),
(3,'2014-04-11');


CREATE TABLE sales(userid integer,created_date date,product_id integer not null primary key); 

INSERT INTO sales(userid,created_date,product_id) 
 VALUES (1,'2017-04-19',2),
(3,'2019-12-18',1),
(2,'2020-07-20',3),
(1,'2019-10-23',2),
(1,'2018-03-19',3),
(3,'2016-12-20',2),
(1,'2016-11-09',1),
(1,'2016-05-20',3),
(2,'2017-09-24',1),
(1,'2017-03-11',2),
(1,'2016-03-11',1),
(3,'2016-11-10',1),
(3,'2017-12-07',2),
(3,'2016-12-15',2),
(2,'2017-11-08',2),
(2,'2018-09-10',3);



CREATE TABLE product(product_id integer,product_name text,price integer,foreign key(product_id) references sales(product_id)); 

INSERT INTO product(product_id,product_name,price) 
 VALUES
(1,'p1',980),
(2,'p2',870),
(3,'p3',330);


select * from sales;
select * from product;
select * from goldusers_signup;
select * from users;

-- when was the frist gold membership taken?
SELECT MIN(gold_signup_date)  AS Date FROM goldusers_signup  ;

-- what is the total amount each customer spent on zomato?
select s.userid, sum(p.price) as total from sales as s inner join product as p on s.product_id=p.product_id group by s.userid; 

-- how many days each customer visited zomato?
select userid,count(distinct created_date)  days from sales group by userid;

-- what was the first product purchased by each customer?
select * from (select c.*, rank() over (partition by userid order by created_date) rnk from
(select * from sales order by created_date)c)d where rnk=1 ;

-- what is the most purchased item on the menu and how many times it ws purchased by all customers?
select userid,count(product_id) from sales where product_id=
(select product_id  from sales group by product_id order by count(product_id)  desc limit 1)
group by userid ;

-- which item was the most popular for each of the customer?
select* from 
(select *, rank() over (partition by userid order by cnt desc) rnk from
(select userid,product_id,count(product_id) as cnt  from sales group by userid,product_id  )c)d where rnk=1;

-- which item was purchased first by the customer after they became a member?
select* from
(select c.*, rank() over (partition by userid order by created_date) rnk from
(select g.userid,g.gold_signup_date, s.created_date,s.product_id from goldusers_signup as g inner join sales as s on g.userid= s.userid and created_date >= gold_signup_date)c)d where rnk=1 ; 

-- which item was purchased by customer just before they became a member?
select* from
(select c.*, rank() over (partition by userid order by created_date desc) rnk from
(select g.userid,g.gold_signup_date, s.created_date,s.product_id from goldusers_signup as g inner join sales as s on g.userid= s.userid and created_date <= gold_signup_date)c)d where rnk=1 ; 

-- what is the total orders and amount spent by each member before they become a member?
select userid, count(created_date) order_purchased, sum(price) total_amt_spent from 
(select c.*, d.price from	
(select s.userid,g.gold_signup_date,s.created_date,s.product_id from goldusers_signup as g inner join 
sales as s on g.userid= s.userid and created_date<=gold_signup_date) as c inner join  product d on c.product_id=d.product_id)e
group by userid ;


-- if buying each product generates points for eg 5rs=2 zomato points and each product has different purchasing points for eg for p1 5rs=1 zomato point ,for p2 10rs= 5 zomato points and p3 5rs= 1 zomato point?
select userid,sum(total_points) from
(select e.*, total_amt/points total_points from
(select d.*,case when product_id=1 then 5 when product_id=2 then 2 when product_id=3 then 5 else  0 end as points from
(select c.userid,c.product_id,sum(price) total_amt from (select s.*,p.price from sales s  inner join product p on s.product_id=p.product_id)c group by userid,product_id)d)e)f group by userid;  


-- in the first year a customer joins the gold program (including their join date) irrespective of what the customer has purchased they earn 5 zomato points for every 10rs spent q- who earned more 1 or 3  and what was their points earnings in their first yr? 
select c.*,p.price*0.5 total_points_earned from 
(select s.* ,g.gold_signup_date from sales as s inner join goldusers_signup g on g.userid=s.userid and gold_signup_date <=created_date
and   created_date<= DATE_ADD(gold_signup_date,interval 1 year))c inner join product p on c.product_id=p.product_id limit 2 ;


-- rank all the transactions of the customers
select*, rank() over(partition by userid order by created_date) rnk from sales;


-- rank all the transactions for each member whenever they are a zomato gold member for every non gold member transaction mark as na 
SELECT e.*, CASE WHEN rnk = 0 THEN 'na' ELSE CAST(rnk AS CHAR) END AS rnkk
FROM (
    SELECT c.*, CASE WHEN gold_signup_date IS NULL THEN 0 ELSE ROW_NUMBER() OVER (PARTITION BY userid ORDER BY created_date DESC) END AS rnk
    FROM (
        SELECT a.userid, a.created_date, a.product_id, b.gold_signup_date
        FROM sales a
        LEFT JOIN goldusers_signup b ON a.userid = b.userid AND a.created_date >= b.gold_signup_date
    ) c
) e;
